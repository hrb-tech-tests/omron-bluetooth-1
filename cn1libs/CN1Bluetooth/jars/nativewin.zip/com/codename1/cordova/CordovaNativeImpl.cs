namespace com.codename1.cordova{

using System;
using System.Windows;

public class CordovaNativeImpl {
    public bool execute(String param, String param1) {
        return false;
    }

    public bool isSupported() {
        return false;
    }

}
}
