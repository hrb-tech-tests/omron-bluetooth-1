(function(exports){

var o = {};

    o.execute__java_lang_String_java_lang_String = function(param1, param2, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.isSupported_ = function(callback) {
        callback.complete(false);
    };

exports.com_codename1_cordova_CordovaNative= o;

})(cn1_get_native_interfaces());
